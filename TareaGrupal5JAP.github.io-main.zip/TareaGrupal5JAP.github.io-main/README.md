# TareaGrupal5JAP.github.io
Tarea grupal la cual consiste en crear un sitio similar a unas imágenes proporcionadas por el curso, siendo el objetivo principal de este el imitar su apariencia en 3 tamaños de pantalla: LG, MD y SM.
